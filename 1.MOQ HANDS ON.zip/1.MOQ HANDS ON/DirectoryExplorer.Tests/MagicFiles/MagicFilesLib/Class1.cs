﻿namespace MagicFilesLib;

public class Class1
{

}
