﻿namespace PlayersManagerLib;

public class Class1
{

}
